var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["a6870703-0124-47f7-acff-dbe905f5014c","5ce44e39-12ac-4a66-88cf-a87a0ed6a180","33841f90-7a53-4346-b956-e51d1961959b"],"propsByKey":{"a6870703-0124-47f7-acff-dbe905f5014c":{"name":"monkey","sourceUrl":null,"frameSize":{"x":560,"y":614},"frameCount":1,"looping":true,"frameDelay":12,"version":"Uw2vsgf41B7.fMOiOLcMGJ1Fy7T.r3g2","loadedFromSource":true,"saved":true,"sourceSize":{"x":560,"y":614},"rootRelativePath":"assets/a6870703-0124-47f7-acff-dbe905f5014c.png"},"5ce44e39-12ac-4a66-88cf-a87a0ed6a180":{"name":"Banana","sourceUrl":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/5ce44e39-12ac-4a66-88cf-a87a0ed6a180.png","frameSize":{"x":1080,"y":1080},"frameCount":1,"looping":true,"frameDelay":4,"version":"6.O6VJX1O0lleT1nmKfcBuwVjIReQ7fb","loadedFromSource":true,"saved":true,"sourceSize":{"x":1080,"y":1080},"rootRelativePath":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/5ce44e39-12ac-4a66-88cf-a87a0ed6a180.png"},"33841f90-7a53-4346-b956-e51d1961959b":{"name":"Stone","sourceUrl":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/33841f90-7a53-4346-b956-e51d1961959b.png","frameSize":{"x":512,"y":512},"frameCount":1,"looping":true,"frameDelay":4,"version":"24ao6.qPnbnaf3ltsN7hCzsVyiHEn8CX","loadedFromSource":true,"saved":true,"sourceSize":{"x":512,"y":512},"rootRelativePath":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/33841f90-7a53-4346-b956-e51d1961959b.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var monkey = createSprite(200,368,50,50);
monkey.setAnimation("monkey");
monkey.scale=0.1;
var jum=0;
var obstacle = createGroup();
var score = 0;

function draw() {
  background(255);
  control();
  createEdgeSprites();
  
  makeRock();
  console.log(monkey.y); 
  text("Score:"+score,200,200);
  
  monkey.collide(edges);
    monkey.collide(obstacle);
    if(monkey.collide(obstacle)) {
      score=0;
      monkey.x=100;
            monkey.y=368;
jum===1;
    }
      
      if((monkey.y!=368)&&(jum===0)) {
        monkey.y=368;
      }
      
    
    drawSprites();
    
  
}
function control() {
  if((jum===0)&&(keyDown("space"))) {
    jum=1;
    monkey.velocityY=-12.5;
  }
  if(monkey.y<150) {
    monkey.velocityY=9;
    
  }
  if(monkey.y>=368) {
    jum=0;
  }
  if(keyDown("a")) {
    monkey.velocityX=-4;
  }
  if(keyWentUp("a")) {
    monkey.velocityX=0;
  }
  if(keyDown("d")) {
    monkey.velocityX=4;
  }
   if(keyWentUp("d")) {
    monkey.velocityX=0;
  }
  
  
}
function makeRock() {
  if((World.frameCount%50===0)&&(jum===0)) {
    var rock = createSprite(-50,375,100,100);
  
    rock.setAnimation("Stone");
    rock.scale=0.2;
    obstacle.add(rock);
    rock.velocityX=score+5;
    score=score+1;
  }
  if((World.frameCount%50===0)&&(jum===0)) {
    var rock = createSprite(450,375,100,100);
  
    rock.setAnimation("Stone");
    rock.scale=0.2;
    obstacle.add(rock);
    rock.velocityX=-score-5;
    score=score+1;
  }
}



  

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
